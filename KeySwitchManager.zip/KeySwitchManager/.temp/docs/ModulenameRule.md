## Domain

- Domain.[Modlue]**s** (*Plural form)
    - Entity/
    - Value/
    - Helper/
    - `Aggregate Classes...`



## Other

- ***LayerName***.[Modlue]**s** (*Plural form)
    - Submodule/

