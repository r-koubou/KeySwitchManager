#!/bin/bash

VERSION=$1
DEST=../../../.nuget/local-packages/

pushd $1
    dotnet build -c Release src/UnitGenerator -p:Version=$VERSION
    dotnet pack ./src/UnitGenerator -c Release --no-build -p:Version=$VERSION -o $DEST
popd
