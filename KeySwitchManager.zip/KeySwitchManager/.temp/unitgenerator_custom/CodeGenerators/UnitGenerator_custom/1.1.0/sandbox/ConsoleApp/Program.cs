﻿using System;
using Sample;
using UnitGenerator;

namespace Sample
{

    [UnitOf(typeof(int), UnitGenerateOptions.ArithmeticOperator | UnitGenerateOptions.ValueArithmeticOperator | UnitGenerateOptions.Comparable | UnitGenerateOptions.MinMaxMethod)]
    public partial class Hp
    {
        // public static Hp operator +(in Hp x, in Hp y) => new Hp(checked((int)(x.value + y.value)));

        void Foo()
        {
            _ = this.AsPrimitive();
        }

    }

    [UnitOf(typeof(int), UnitGenerateOptions.MessagePackFormatter)]
    public partial class UserId { }


    [UnitOf(typeof(int), UnitGenerateOptions.Validate)]
    public partial class SampleValidate
    {
        // impl here.
        private partial int Validate(int validationValue )
        {
            if (validationValue > 9999) throw new Exception("Invalid value range: " + validationValue);
            return validationValue;
        }
    }

    [UnitOf(typeof(int), UnitGenerateOptions.MessagePackFormatter)]
    public partial class UserId2
    {
        public void Foo()
        {


            _ = AsPrimitive();
        }
    }

}


namespace ConsoleApp
{


    [UnitOf(typeof((string street, string city)))]
    public partial class StreetAddress { }

    class Program
    {
        static void Foo(short x)
        {
        }

        static void Main(string[] args)
        {
            new SampleValidate(99999);


            default(StreetAddress).AsPrimitive();

        }
    }

}





