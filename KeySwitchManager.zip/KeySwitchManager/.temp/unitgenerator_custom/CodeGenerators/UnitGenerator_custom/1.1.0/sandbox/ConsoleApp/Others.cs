﻿using System;
using UnitGenerator;

namespace ConsoleApp
{
    [UnitOf(typeof(Guid), UnitGenerateOptions.ParseMethod | UnitGenerateOptions.Validate | UnitGenerateOptions.DapperTypeHandler | UnitGenerateOptions.EntityFrameworkValueConverter)]
    public partial class GD
    {
        private partial Guid Validate(Guid validationValue ) => validationValue;
    }
    [UnitOf(typeof(DateTime), UnitGenerateOptions.ParseMethod | UnitGenerateOptions.Validate | UnitGenerateOptions.DapperTypeHandler | UnitGenerateOptions.EntityFrameworkValueConverter)]
    public partial class DT
    {
        private partial DateTime Validate(DateTime validationValue ) => validationValue;
    }
    [UnitOf(typeof(string), UnitGenerateOptions.Validate | UnitGenerateOptions.DapperTypeHandler | UnitGenerateOptions.EntityFrameworkValueConverter)]
    public partial class ST
    {
        private partial string Validate(string validationValue ) => validationValue;
    }
    [UnitOf(typeof(byte[]), UnitGenerateOptions.Validate | UnitGenerateOptions.DapperTypeHandler | UnitGenerateOptions.EntityFrameworkValueConverter)]
    public partial class BA
    {
        private partial byte[] Validate(byte[] validationValue ) => validationValue;
    }
}
