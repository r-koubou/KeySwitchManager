using System.Collections.Generic;

namespace KeySwitchManager.Xlsx.KeySwitches.Models
{
    public class Workbook
    {
        public readonly List<Worksheet> Worksheets = new List<Worksheet>();
    }
}