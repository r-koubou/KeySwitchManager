# Seguridad

## Cifrado

Actualmente ASF soporta los siguientes métodos de cifrado como una definición de `ECryptoMethod`:

| Valor | Nombre                      |
| ----- | --------------------------- |
| 0     | PlainText                   |
| 1     | AES                         |
| 2     | ProtectedDataForCurrentUser |

La descripción exacta y comparación de las mismas están disponibles a continuación.

Para generar una contraseña cifrada, por ejemplo, para uso de `SteamPassword`, debes ejecutar el **[comando](https://github.com/JustArchiNET/ArchiSteamFarm/wiki/Commands-es-es)** `encrypt` con el cifrado que elegiste y tu contraseña en texto plano. Posteriormente, introduce la cadena de caracteres cifrada obtenida en la propiedad de configuración del bot `SteamPassword`, y finalmente cambia `PasswordFormat` al que corresponda con el método de cifrado elegido.

* * *

### PlainText

Esta es la forma más sencilla e insegura de almacenar una contraseña, definida como `ECryptoMethod` de `0`. ASF espera que la cadena de caracteres sea texto plano - una contraseña en su forma directa. Es la más fácil de usar, y 100% compatible con todas las configuraciones, por lo tanto es una forma predeterminada de almacenar secretos, totalmente insegura para almacenamiento.

* * *

### AES

Considerado seguro para los estándares actuales, la forma **[AES](https://es.wikipedia.org/wiki/Advanced_Encryption_Standard)** de almacenar la contraseña es definida como `ECryptoMethod` de `1`. ASF espera que la cadena sea una secuencia de caracteres **[base64-encoded](https://es.wikipedia.org/wiki/Base64)** resultante en un "byte array" cifrado en AES después de la traducción, que luego debe ser descifrado usando el **[vector de inicialización](https://es.wikipedia.org/wiki/Vector_de_inicializaci%C3%B3n)** incluido y la clave de cifrado de ASF.

El método anterior garantiza la seguridad siempre que el atacante no conozca la clave de encriptación integrada en ASF, la cual es usada tanto para la desencriptación como para la encriptación de contraseñas. ASF te permite especificar la clave a través del **[argumento de la línea de comandos](https://github.com/JustArchiNET/ArchiSteamFarm/wiki/Command-Line-Arguments-es-es)** `--cryptkey`, el cual deberías usar para máxima seguridad. Si decides omitirlo, ASF usará su propia clave que es **conocida** y está en el código de la aplicación, lo que significa que cualquiera puede revertir la encriptación de ASF y obtener la contraseña desencriptada. Requiere algo de esfuerzo y no es tan fácil de hacer, pero es posible, por eso casi siempre debes usar la encriptación `AES` con tu propia `--cryptkey` que es mantenida en secreto. El método AES usado en ASF proporciona seguridad que debería ser satisfactoria y tiene un balance entre la simplicidad de `PlainText` y la complejidad de `ProtectedDataForCurrentUser`, pero se recomienda mucho usarlo con una `--cryptkey` personalizada. Si se utiliza correctamente, garantiza una seguridad decente para el almacenamiento seguro.

* * *

### ProtectedDataForCurrentUser

Actualmente es la forma más segura que ofrece ASF para cifrar la contraseña, y mucho más segura que el método `AES` explicado anteriormente, se define como `ECryptoMethod` de `2`. La ventaja principal de este método es al mismo tiempo la mayor desventaja - en lugar de usar una clave de encriptación (como en `AES`), la información es encriptada usando las credenciales de inicio de sesión del usuario que actualmente tiene la sesión iniciada, lo que significa que es posible desencriptar la información **solo** en la máquina en la que fue encriptada, y además **solo** por el usuario que hizo la encriptación. Esto asegura que incluso si envías todo tu `Bot.json` con `SteamPassword` cifrada usando este método a alguien más, no será capaz de descifrar la contraseña sin acceso directo a tu PC. Esta es una excelente medida de seguridad, pero al mismo tiempo tiene la gran desventaja de ser menos compatible, ya que la contraseña cifrada usando este método no será compatible con ningún otro usuario ni otra máquina - incluyendo **la tuya propia** si decides, por ejemplo, reinstalar tu sistema operativo. Aún así, es uno de los mejores método para almacenar contraseñas, y si te preocupa la seguridad de `PlainText`, y no quieres introducir tu contraseña cada vez, entonces esta es tu mejor opción siempre que no tengas que acceder a tus configuraciones desde otra máquina que no sea la tuya.

**Por favor, ten en cuenta que actualmente esta opción solo está disponible para máquinas que ejecuten el sistema operativo Windows.**

* * *

## Recomendación

Si la compatibilidad no es un problema para ti, y estás bien con cómo funciona el método `ProtectedDataForCurrentUser`, es la opción **recomendada** para almacenar la contraseña en ASF, ya que proporciona la mejor seguridad. El método `AES` es una buena opción para las personas que quieren usar sus configuraciones en cualquiera máquina que quieran, mientras que `PlainText` es la forma más simple de almacenar la contraseña, si no te importa que cualquiera pueda buscarla en la configuración JSON.

Por favor, ten en cuenta que los 3 métodos se consideran **inseguros** si el atacante tiene acceso a tu PC. ASF debe poder descifrar las contraseñas cifradas, y si el programa que se ejecuta en tu máquina puede hacer eso, entonces cualquier programa que se ejecute en la misma máquina será capaz de hacerlo también. `ProtectedDataForCurrentUser` es la variante más segura ya que **incluso otro usuario usando la misma PC no podrá desencriptarla**, pero aún es posible desencriptar la información si alguien es capaz de robar tus credenciales de acceso e información de tu máquina además del archivo de configuración de ASF.

Además de los métodos de cifrado especificados anteriormente, también es posible evitar especificar contraseñas completamente, por ejemplo, en `SteamPassword` al usar un cadena de caracteres vacía o el valor `null`. ASF pedirá tu contraseña cuando sea necesario, y no la guardará en ningún lugar, solo la mantendrá en la memoria del proceso actual, hasta que lo cierres. Mientras que es el método más seguro de tratar con contraseñas (no se guardan en ningún lugar), también es el más problemático ya que necesitas introducir tu contraseña manualmente en cada ejecución de ASF (cuando sea requerido). Si eso no es un problema para ti, esta es tu mejor apuesta en lo que se refiere a seguridad.

* * *

## Desencriptación

ASF no soporta ninguna forma de desencriptar contraseñas ya encriptadas, ya que los métodos de desencriptación solo son usados internamente para acceder a la información dentro del proceso. Si deseas revertir el procedimiento de cifrado, por ejemplo, para mover ASF a otra máquina al usar `ProtectedDataForCurrentUser`, entonces simplemente repite el procedimiento desde el principio en el nuevo entorno.

* * *

## Hashing

Actualmente ASF soporta los siguientes métodos de hashing como una definición de `EHashingMethod`:

| Valor | Nombre    |
| ----- | --------- |
| 0     | PlainText |
| 1     | SCrypt    |
| 2     | Pbkdf2    |

La descripción exacta y comparación de las mismas están disponibles a continuación.

Para generar un hash, por ejemplo, para uso de `IPCPassword`, debes ejecutar el **[comando](https://github.com/JustArchiNET/ArchiSteamFarm/wiki/Commands-es-es)** `hash` con el método de hashing que elegiste y tu contraseña en texto plano. Posteriormente, introduce la cadena de caracteres con hash obtenida en la propiedad de configuración de ASF `IPCPassword`, y finalmente cambia `IPCPasswordFormat` al que corresponda con el método de hashing elegido.

* * *

### PlainText

Esta es la forma más sencilla e insegura de aplicarle hashing a una contraseña, definida como `EHashingMethod` de `0`. ASF generará un hash que coincida con la entrada original. Es la más fácil de usar, y 100% compatible con todas las configuraciones, por lo tanto es una forma predeterminada de almacenar secretos, totalmente insegura para almacenamiento.

* * *

### SCrypt

Considerado seguro para los estándares actuales, el método **[SCrypt](https://en.wikipedia.org/wiki/Scrypt)** de aplicar hash a la contraseña es definido como `EHashingMethod` de `1`. ASF usará la implementación de `SCrypt` utilizando `8` bloques, `8192` iteraciones, longitud de hash `32` y la clave de cifrado como sal para generar el array de bytes. Los bytes resultantes serán codificados como una cadena de caracteres **[base64](https://es.wikipedia.org/wiki/Base64)**.

ASF te permite especificar la sal para este método a través del **[argumento de la línea de comandos](https://github.com/JustArchiNET/ArchiSteamFarm/wiki/Command-Line-Arguments-es-es)** `--cryptkey`, el cual deberías usar para máxima seguridad. Si decides omitirlo, ASF usará su propia clave que es **conocida** y está codificada en la aplicación, lo que significa que el hashing será menos seguro. Si se utiliza correctamente, garantiza una seguridad decente para el almacenamiento seguro.

* * *

### Pbkdf2

Considerado débil para los estándares actuales, el método **[Pbkdf2](https://en.wikipedia.org/wiki/PBKDF2)** de aplicar hash a la contraseña es definido como `EHashingMethod` de `2`. ASF usará la implementación de `Pbkdf2` utilizando `10000` iteraciones, longitud de hash `32` y la clave de cifrado como sal, con `SHA-256` como algoritmo hmac para generar el array de bytes. Los bytes resultantes serán codificados como una cadena de caracteres **[base64](https://es.wikipedia.org/wiki/Base64)**.

ASF te permite especificar la sal para este método a través del **[argumento de la línea de comandos](https://github.com/JustArchiNET/ArchiSteamFarm/wiki/Command-Line-Arguments-es-es)** `--cryptkey`, el cual deberías usar para máxima seguridad. Si decides omitirlo, ASF usará su propia clave que es **conocida** y está codificada en la aplicación, lo que significa que el hashing será menos seguro.

* * *

## Recomendación

Si quieres usar un método de hashing par almacenar algunos secretos, tal como `IPCPassword`, recomendamos usar `SCrypt` con sal personalizada, ya que proporciona una seguridad muy decente contra intentos de fuerza bruta. `Pbkdf2` solo se ofrece por razones de compatibilidad, principalmente porque ya tenemos una implementación funcional (y necesaria) de esta para otros casos en la plataforma de Steam (por ejemplo, códigos parentales). Se considera seguro, pero débil en comparación con otras alternativas (por ejemplo, `SCrypt`).