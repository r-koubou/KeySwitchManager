namespace KeySwitchManager.Commons.Data
{
    public interface IText
    {
        public string Value { get; }
    }
}